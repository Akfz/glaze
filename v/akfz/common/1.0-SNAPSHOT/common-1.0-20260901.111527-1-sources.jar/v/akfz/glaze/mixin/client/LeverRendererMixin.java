package v.akfz.glaze.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import v.akfz.glaze.impl.post.PostProcessRenderer;

@Mixin(class_761.class)
public class LeverRendererMixin {
	@Shadow @Final private class_310 minecraft;

	@Inject(method = "renderLevel", at= @At("TAIL"))
	public void onEndOfRenderLevel(class_4587 pPoseStack,float pPartialTick,long pFinishNanoTime,boolean pRenderBlockOutline,class_4184 pCamera,class_757 pGameRenderer,class_765 pLightTexture,Matrix4f pProjectionMatrix,CallbackInfo ci) {
		PostProcessRenderer postProcessRenderer = PostProcessRenderer.INSTANCE;
		if (!postProcessRenderer.renderGlobal) {
			postProcessRenderer.render(minecraft.method_1522());
		}
	}
}
