package v.akfz.glaze.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import v.akfz.glaze.impl.post.PostProcessRenderer;

@Mixin(class_757.class)
public class GameRendererMixin {
	@Shadow @Final class_310 minecraft;

	@Inject(method = "render(FJZ)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;flush()V"))
	public void glaze$onPostProcessRenderer(float pPartialTicks,long pNanoTime,boolean pRenderLevel,CallbackInfo ci) {
		PostProcessRenderer postProcessRenderer = PostProcessRenderer.INSTANCE;
		if (postProcessRenderer.renderGlobal) {
			postProcessRenderer.render(minecraft.method_1522());
		}
	}
}
