package v.akfz.glaze.impl.post;

import net.minecraft.class_2960;
import v.akfz.glazelib.shader.impl.ShaderProgram;

public class PostProcessShader extends ShaderProgram {
	private static final class_2960 DEFAULT_VERTEX =
			new class_2960("glaze", "shader/vertex.glsl");

	public PostProcessShader(class_2960 fragmentLocation) {
		super(DEFAULT_VERTEX, fragmentLocation);
	}

	public PostProcessShader(String fragmentSource) {
		super(DEFAULT_VERTEX, fragmentSource);
	}
}