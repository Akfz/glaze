package v.akfz.glaze.impl.post;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;
import v.akfz.glaze.Glaze;
import v.akfz.glazelib.shader.api.IShaderProgram;
import v.akfz.glazelib.shader.api.ShaderUniformManager;
import v.akfz.glazelib.util.PingPongBuffer;
import v.akfz.glazelib.util.QuadMesh;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_276;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5944;

public class PostProcessRenderer {
	public static final PostProcessRenderer INSTANCE = new PostProcessRenderer();

	public boolean renderGlobal = true;

	private final List<class_2960> pendingShaders = new ArrayList<>();
	private final List<PostProcessShader> shaders = new ArrayList<>();

	private QuadMesh quadMesh;
	private PingPongBuffer pingPong;

	private int cachedWidth = -1;
	private int cachedHeight = -1;
	private boolean meshInitialized = false;
	private boolean initialized = false;

	private PostProcessRenderer() {}

	public void render(class_276 mainBuffer) {
		if (mainBuffer == null) return;
		if (!Glaze.postProcess) return;

		checkInit();
		if (shaders.isEmpty()) return;

		int width = mainBuffer.field_1482;
		int height = mainBuffer.field_1481;
		if (width <= 0 || height <= 0) return;

		ensureResources(width, height);

		class_5944 previousShader = RenderSystem.getShader();
		boolean scissorEnabled = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);

		GlStateManager._disableDepthTest();
		GlStateManager._disableBlend();
		GlStateManager._disableCull();
		if (scissorEnabled) GL11.glDisable(GL11.GL_SCISSOR_TEST);

		blit(mainBuffer, pingPong.front());
		pingPong.front().method_29329(mainBuffer);

		int depthTextureId = pingPong.front().method_30278();
		float nearPlane = 0.05f;
		float farPlane = class_310.method_1551().field_1690.method_42503().method_41753() * 16.0f;

		for (IShaderProgram shader : shaders) {
			if (!shader.isValid()) continue;

			class_276 input = pingPong.front();
			class_276 output = pingPong.back();

			GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, output.field_1476);
			GL11.glViewport(0, 0, width, height);
			GL11.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
			GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);

			final int inputColor = input.method_30277();
			final int depthId = depthTextureId;

			shader.use(() -> {
				ShaderUniformManager um = shader.getUniformManager();

				RenderSystem.activeTexture(GL13.GL_TEXTURE0);
				GL11.glBindTexture(GL11.GL_TEXTURE_2D, inputColor);
				um.setTexture("uTexture", 0);

				if (depthId != 0) {
					RenderSystem.activeTexture(GL13.GL_TEXTURE1);
					GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthId);
					um.setTexture("uDepth", 1);
				}

				um.set("uNear", nearPlane);
				um.set("uFar", farPlane);
				um.set("uResolution", new org.joml.Vector2f(width, height));
				um.set("uTime", (float) (System.currentTimeMillis() % 100000L) / 1000.0f);

				quadMesh.render();
			});

			pingPong.swap();
		}

		class_276 finalResult = pingPong.front();
		if (finalResult != mainBuffer) {
			blit(finalResult, mainBuffer);
		}

		GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, mainBuffer.field_1476);
		GlStateManager._enableDepthTest();
		GlStateManager._enableBlend();
		GlStateManager._enableCull();
		if (scissorEnabled) GL11.glEnable(GL11.GL_SCISSOR_TEST);

		RenderSystem.activeTexture(GL13.GL_TEXTURE1);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
		RenderSystem.activeTexture(GL13.GL_TEXTURE0);
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);

		if (previousShader != null) {
			RenderSystem.setShader(() -> previousShader);
			previousShader.method_34586();
		} else {
			RenderSystem.setShader(() -> null);
			GlStateManager._glUseProgram(0);
		}
	}

	private void ensureResources(int w, int h) {
		if (cachedWidth == w && cachedHeight == h && pingPong != null) return;

		if (!meshInitialized) {
			if (quadMesh == null) quadMesh = new QuadMesh();
			quadMesh.init();
			meshInitialized = true;
		}

		if (pingPong != null) pingPong.destroy();

		pingPong = new PingPongBuffer(true);
		pingPong.ensureSize(w, h);

		cachedWidth = w;
		cachedHeight = h;
	}

	private void blit(class_276 source, class_276 target) {
		GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, source.field_1476);
		GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, target.field_1476);
		GL30.glBlitFramebuffer(
				0, 0, source.field_1482, source.field_1481,
				0, 0, target.field_1482, target.field_1481,
				GL11.GL_COLOR_BUFFER_BIT,
				GL11.GL_NEAREST
		);
	}

	public void cleanup(boolean cleanShaders) {
		if (pingPong != null) {
			pingPong.destroy();
			pingPong = null;
		}
		if (quadMesh != null && meshInitialized) {
			quadMesh.destroy();
			meshInitialized = false;
		}
		if (cleanShaders) {
			shaders.forEach(PostProcessShader::cleanup);
			shaders.clear();
			pendingShaders.clear();
		}
		initialized = false;
		cachedWidth = -1;
		cachedHeight = -1;
	}

	private void checkInit() {
		if (initialized || pendingShaders.isEmpty()) return;

		shaders.forEach(PostProcessShader::cleanup);
		shaders.clear();

		for (class_2960 fragment : pendingShaders) {
			try {
				shaders.add(new PostProcessShader(fragment));
			} catch (Exception e) {
				System.err.println("[Glaze] Failed to compile shader: " + fragment);
				e.printStackTrace();
			}
		}
		initialized = true;
	}

	public void addShader(class_2960 fragmentShader) {
		if (!pendingShaders.contains(fragmentShader)) {
			pendingShaders.add(fragmentShader);
			initialized = false;
		}
	}

	public void addShader(PostProcessShader shader) {
		shaders.add(shader);
	}

	public void removeShader(PostProcessShader sh) {
		shaders.remove(sh);
	}

	public void removeShader(class_2960 fragmentShaderPath) {
		if (pendingShaders.remove(fragmentShaderPath)) initialized = false;
		shaders.removeIf(shader -> {
			class_2960 loc = shader.getFragmentLocation();
			return loc != null && loc.equals(fragmentShaderPath);
		});
	}

	public List<PostProcessShader> getShaders() {
		return new ArrayList<>(shaders);
	}

	public void reload() {
		initialized = false;
		cachedWidth = -1;
		cachedHeight = -1;
	}
}