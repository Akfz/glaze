package v.akfz.glazelib.util;

import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_6367;

public class PingPongBuffer {
	private class_276 front;
	private class_276 back;
	private int width, height;
	private boolean hasDepth;

	public PingPongBuffer(boolean hasDepth) {
		this.hasDepth = hasDepth;
	}

	public void ensureSize(int w, int h) {
		if (width == w && height == h && front != null) return;
		destroy();
		this.width = w;
		this.height = h;
		this.front = new class_6367(w, h, hasDepth, class_310.field_1703);
		this.back = new class_6367(w, h, hasDepth, class_310.field_1703);
	}

	public class_276 front() { return front; }
	public class_276 back() { return back; }

	public void swap() {
		class_276 tmp = front;
		front = back;
		back = tmp;
	}

	public class_276 result() { return front; }

	public void destroy() {
		if (front != null) { front.method_1238(); front = null; }
		if (back != null) { back.method_1238(); back = null; }
	}
}